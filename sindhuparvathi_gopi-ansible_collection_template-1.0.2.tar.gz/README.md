Ansible Collection tempalte 
==================================

